package definitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static support.TestContext.driver;
import static support.TestContext.getDriver;

public class ATStepdefs {
    @Given("AT navigate to {string} website")
    public void atNavigateToWebsite(String URL) {
        if (URL.equalsIgnoreCase("contact-list")) {
            getDriver().get("https://thinking-tester-contact-list.herokuapp.com/");
        } else {
            System.out.println("Bad URL");
        }
    }

    @Then("AT verify page title {string}")
    public void atVerifyPageTitle(String expectedTitle) {
        String actualTitle = getDriver().getTitle();
        assertThat(actualTitle)
                .as("Page title should match expected value")
                .isEqualToIgnoringCase(expectedTitle);
    }

    @When("AT click on {string} button")
    public void atClickOnButton(String button) {
        String buttonId = switch (button.toLowerCase()) {
            case "sign up" -> "signup";
            case "submit" -> "submit";
            case "logout" -> "logout";
            case "add a new contact" -> "add-contact";
            case "delete" -> "delete";
            case "return to contact list"-> "return";

            default -> throw new IllegalArgumentException("Invalid button: " + button);
        };

        getDriver().findElement(By.id(buttonId)).click();
    }

    @When("AT enter {string} for the First Name, {string} for the Last Name, {string} for the Email and {string} for the Password")
    public void atEnterUserDetails(String firstName, String lastName, String email, String password) {
        enterTextById("firstName", firstName);
        enterTextById("lastName", lastName);
        enterTextById("email", email);
        enterTextById("password", password);
    }

    private void enterTextById(String fieldId, String value) {
        WebElement field = getDriver().findElement(By.id(fieldId));
        field.clear();
        field.sendKeys(value);
    }

    @And("AT verify confirmation message {string}")
    public void atVerifyConfirmationMessage(String arg0) {
        WebElement confirmationMessage = driver.findElement(By.className("alert"));
        String actualMessage = confirmationMessage.getText();
        assertThat(actualMessage).contains("Registration successful. Please check your email for confirmation");

    }


    @When("AT enter {string} for the {string} field")
    public void atEnterForTheField(String value, String fieldName) {
        {
            By fieldLocator = getFieldLocator(fieldName);

            if (fieldLocator != null) {
                WebElement field = driver.findElement(fieldLocator);
                field.clear();
                field.sendKeys(value);
            } else {
                throw new IllegalArgumentException("Invalid field name: " + fieldName);
            }
        }

    }

    private By getFieldLocator(String fieldName) {
        switch (fieldName.toLowerCase()) {
            case "first name":
                return By.id("firstName");
            case "last name":
                return By.id("lastName");
            case "email":
                return By.id("email");
            case "password":
                return By.id("password");
            case "date of birth":
                return By.id("birthdate");
            case "phone":
                return By.id("phone");
            case "street address 1":
                return By.id("street1");
            case "street address 2":
                return By.id("street2");
            case "city":
                return By.id("city");
            case "state of province":
                return By.id("stateProvince");
            case "postal code":
                return By.id("postalCode");
            case "country":
                return By.id("country");

            default:
                return null;
        }
    }


    @And("AT wait for {int} sec")
    public void atWaitForSec(int sec) throws InterruptedException {
        Thread.sleep(sec * 1000);
    }

  

    @Then("AT click on {string} under Name column")
    public void atClickOnUnderNameColumn(String arg0) {
        getDriver().findElement(By.xpath("//td[contains(text(),'Peter Smith')]")).click();
    }

    @Then("AT click {string} on pop up window")
    public void atClickOnPopUpWindow(String action) {
        Alert alert = new WebDriverWait(driver, Duration.ofSeconds(5))
                .until(ExpectedConditions.alertIsPresent());
        if (action.equalsIgnoreCase("ok")) {
            alert.accept();
        } else if (action.equalsIgnoreCase("Cancel")) {
            alert.dismiss();

        }
    }


    @And("AT verify contact is {string}")
    public void atVerifyContactStatus(String status) {
        boolean isContactPresent = !getDriver().findElements(By.xpath("//td[contains(text(),'Peter Smith')]")).isEmpty();

        if ("added".equalsIgnoreCase(status)) {
            assertThat(isContactPresent)
                    .as("Contact should be added and present in the list")
                    .isTrue();
        } else if ("deleted".equalsIgnoreCase(status)) {
            assertThat(isContactPresent)
                    .as("Contact should be deleted and not present in the list")
                    .isFalse();
        } else if ("present".equalsIgnoreCase(status)) {
            assertThat(isContactPresent)
                    .as("Contact should be present in the list")
                    .isTrue();
        }else {
            throw new IllegalArgumentException("Invalid status: " + status + ". Use 'added', 'deleted' or 'present'.");
        }
    }

}