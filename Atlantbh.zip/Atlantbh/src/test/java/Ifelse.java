import net.sourceforge.htmlunit.corejs.javascript.ast.WhileLoop;

import java.util.Scanner;

public class Ifelse {
    public static void main(String[] arg) {
    isLarge(10);



//        int[] numbers = {2, 5, 388, 79, -1};
//        //String[] names = {"Manisha", "Quang", "Snigdha"};
//        //boolean[] values = {true, false, false, true};
//
//
//        for (int j = 0; j < numbers.length; j++) {
//            System.out.println("the numberzzzzzzz is " + numbers[j]);
//        }
//        int i=0;
//        while (i < numbers.length) {
//            System.out.println("The numbers is " + numbers[i]);
//            i++;
//        }
//    }


  //  public static void main(String[] args) {
//        int[] numbers = {3, 7, 87, -101, 55};

//        for (int i = 0; i < numbers.length; i++) {
//            System.out.println("You choose " + numbers[i]);
//        }


    }
    public static void isLarge(int broj){
        if (broj==5){
            System.out.println("you are right");
        }
        else if (broj==4){
            System.out.println("close enough");
        }
        else{
            System.out.println("you can guess good");
        }
    }
}


