package support;

import java.util.Scanner;

public class Java4life {
    public static void main(String[] args) {

        Car Honda=new Car(34,50);
        Car Audi= new Car(45,25);

        System.out.println(Honda.distance);
        System.out.println(Audi.distance);

        System.out.println(Honda.fuelLevel);
        System.out.println(Audi.fuelLevel);


//      System.out.println(Honda.drive(400));
        System.out.println(Honda.fuelUp(18));
//
//      System.out.println(Audi.drive(400));
        System.out.println(Audi.fuelUp(15));


//        House cozy1bd= new House(350, 7500);
//        House twoBtwoB=new House(800,1200000);
//
//        //System.out.println(cozy1bd.price);
//        System.out.println(cozy1bd.appreciation(3000));
//        System.out.println(twoBtwoB.appreciation(3000));

    }
 //       isLarge(3);
//        printOutString();
//        printOutInt();
//        printOutBoolean();
//        printOutSumOfTwoStrings();
//        printOutAddition();
//        printOutSubtraction();
//        printOutMultiplication();
//        printOutDivision();
//        printOutModulus();
//        printOutComparisonOperators();
//        printOutLogicalOperators();



//    }
//
//    public static void printOutString() {
//        Scanner scanner = new Scanner(System.in);
//        //System.out.println("String");
//        System.out.println("Enter your string:");
//        String string = scanner.nextLine();
//    }
//
//    public static void printOutInt() {
//        System.out.println("Int");
//    }
//
//    public static void printOutBoolean() {
//        System.out.println("Boolean");
//    }
//
//    public static void printOutSumOfTwoStrings() {
//       String name1="Good";
//        String name2="Afternoon";
//        System.out.println(name1  +" "+  name2);
//    }
//    public static void printOutAddition() {
//        int num1=15;
//        int num2=3;
//        System.out.println(num1+num2);
//    }
//    public static void printOutSubtraction() {
//        int num1=15;
//        int num2=3;
//        System.out.println(num1-num2);
//    }
//    public static void printOutMultiplication() {
//        int num1=15;
//        int num2=3;
//        System.out.println(num1*num2);
//    }
//    public static void printOutDivision() {
//        int num1=15;
//        int num2=3;
//        System.out.println(num1/num2);
//    }
//    public static void printOutModulus() {
//        int num1=15;
//        int num2=3;
//        System.out.println(num1%num2);
//    }
//    public static void printOutComparisonOperators() {
//        int num1=15;
//        int num2=3;
//        System.out.println(num1==num2);
//        System.out.println(num1!=num2);
//        System.out.println(num1>num2);
//        System.out.println(num1<num2);
//        System.out.println(num1>=num2);
//        System.out.println(num1<=num2);
//    }
//
//    public static void printOutLogicalOperators() {
//        int num1=15;
//        int num2=3;
//        System.out.println(num1>num2 && num2<num1);
//        System.out.println(num1>num2 || num2<num1);
//    }
//
//
//    public static void isLarge(int num){
//        if(num>5){
//            System.out.println("This number is great");
//        }else {
//            System.out.println("This number kinda suxxxx");
//        }
 //  }
}



