package support;

public class Car {
     public int fuelLevel;
     public int distance;

     public Car (int fuelLevel,int distance){
         this.distance=distance;
         this.fuelLevel=fuelLevel;
     }

     public int drive(int miles){
         miles=distance+miles;
         return miles;
     }

     public int fuelUp(int gallons){
         gallons=fuelLevel+gallons;
         return gallons;
     }
}
