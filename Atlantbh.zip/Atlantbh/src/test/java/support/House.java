package support;

public class House {

    public int squareFootage;
    public int price;

    public House (int squareFootage, int price){
        this.price=price;
        this.squareFootage=squareFootage;
    }

    public int appreciation(int dollars){
        price=price+dollars;
        return price;
    }
}
