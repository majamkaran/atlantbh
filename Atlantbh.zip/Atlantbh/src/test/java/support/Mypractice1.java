package support;

import java.util.Scanner;

//import static support.Java4life.printOutString;

//public class Mypractice1 {
//    public static void main(String[] args) {
//        printOutString();
//        printOutInt();
//        printOutBoolean();
//        printOutSumOfStrings();
//        printAdvanced1();
//        printAdvanced2();
//
//    }
//
//    public static void printOutString() {
//        Scanner scanner = new Scanner(System.in);
//        //System.out.println("String");
//        System.out.println("Enter your name:");
//        String string = scanner.nextLine();
//        System.out.println("Hi " + string + ", Nice to meet you!");
//    }
//
//    public static void printOutInt() {
//        Scanner scanner = new Scanner(System.in);
//        //System.out.println("String");
//        System.out.println("Enter your number:");
//        int num = scanner.nextInt();
//        System.out.println("Hi, your number is " + num);
//    }
//
//    public static void printOutBoolean() {
//        Scanner scanner = new Scanner(System.in);
//        //System.out.println("String");
//        System.out.println("Enter your boolean:");
//        boolean boo = scanner.nextBoolean();
//        System.out.println("Hi, your boolean is " + boo);
//    }
//    public static void printOutSumOfStrings() {
//        Scanner scanner = new Scanner(System.in);
//        //System.out.println("String");
//        System.out.println("Enter your name:");
//        String one = scanner.nextLine();
//        scanner = new Scanner(System.in);
//        //System.out.println("String");
//        System.out.println("Enter your last name:");
//        String two = scanner.nextLine();
//        System.out.println("Your name is " + one + " " +  two);
//    }
//    public static void printAdvanced1() {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter one number for math:");
//        int num1 = scanner.nextInt();
//        System.out.println("Enter another number:");
//        int num2 = scanner.nextInt();
//        System.out.println("Enter an operator: '+' , '-' , '*' , or '/' : ");
//        char operator = scanner.next().charAt(0);
//        int result = 0;
//        switch (operator) {
//            case '+':
//                result = num1 + num2;
//                break;
//            case '-':
//                result = num1 - num2;
//                break;
//            case '*':
//                result = num1 * num2;
//                break;
//            case '/':
//                result = num1 / num2;
//                break;
//            default:
//                System.out.println("Invalid operator.");
//                break;
//        }
//        System.out.println("Here's the math result: " + result);
//    }
//    public static void printAdvanced2() {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter comparison operator (==, >=,<=, !=): ");
//       String operator = scanner.nextLine();
//        System.out.println("Enter first number:");
//        int num1 = scanner.nextInt();
//        System.out.println("Enter second number: ");
//        int num2 = scanner.nextInt();
//        boolean result = true;
//        switch (operator) {
//            case "==":
//                result = num1 == num2;
//                break;
//            case ">=":
//                result = num1 >= num2;
//                break;
//            case "<=":
//                result = num1 <= num2;
//                break;
//            case "!=":
//                result = num1 != num2;
//                break;
//            default:
//                System.out.println("Invalid comparison operator.");
//        }
//        System.out.println("Here's the logic result: " + result);
//    }
//}